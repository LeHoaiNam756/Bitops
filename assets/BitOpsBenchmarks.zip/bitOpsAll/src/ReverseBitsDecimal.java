public class ReverseBitsDecimal {
    public static int reverseBitsDecimal(int n) {
        int rev = 0;
        while(n!=0) {
            rev <<= 1;
            if ((n&1)!=0) {
                rev ^= 1;
            }
            n >>= 1;
        }
        return rev;
    }

}
