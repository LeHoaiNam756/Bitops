/**
 * PixelColorMixer performs low-level color manipulation using bitwise operations.
 * <p>
 * Each pixel is represented in 32-bit ARGB format:
 * 0xAARRGGBB
 *
 * The algorithm blends two colors and conditionally applies filters
 * (brightness, red/green emphasis) using bitwise masks (0xFF...).
 *
 * <p>Example usage:
 * <pre>
 *     int c1 = 0xFF3366FF; // blueish
 *     int c2 = 0xFFFF6600; // orange
 *     int mixed = PixelColorMixer.mixColors(c1, c2, true);
 * </pre>
 */
public final class PixelColorMixer {

    private PixelColorMixer() {}

    /**
     * Blends two colors and conditionally adjusts brightness and color emphasis.
     *
     * @param color1 first ARGB color (0xAARRGGBB)
     * @param color2 second ARGB color (0xAARRGGBB)
     * @param emphasizeRed whether to emphasize red tones (else green tones)
     * @return mixed color as ARGB 0xAARRGGBB
     */
    public static int mixColors(int color1, int color2, boolean emphasizeRed) {
        // Extract color channels using bitmasking
        int a1 = (color1 >>> 24) & 0xFF;
        int r1 = (color1 >>> 16) & 0xFF;
        int g1 = (color1 >>> 8) & 0xFF;
        int b1 = (color1) & 0xFF;

        int a2 = (color2 >>> 24) & 0xFF;
        int r2 = (color2 >>> 16) & 0xFF;
        int g2 = (color2 >>> 8) & 0xFF;
        int b2 = (color2) & 0xFF;

        // Average blend for each channel
        int a = (a1 + a2) >>> 1;
        int r = (r1 + r2) >>> 1;
        int g = (g1 + g2) >>> 1;
        int b = (b1 + b2) >>> 1;

        // Conditional color emphasis
        if (emphasizeRed) {
            // Boost red slightly using OR with 0x20 (bitwise color enhancement)
            r = Math.min(r | 0x20, 0xFF);
            g = g & 0xF0; // reduce green
        } else {
            // Boost green slightly and reduce red
            g = Math.min(g | 0x30, 0xFF);
            r = r & 0xE0;
        }

        // Brightness correction: if average of RGB < 128 → brighten
        int brightness = (r + g + b) / 3;
        if (brightness < 128) {
            r = Math.min(r + 0x20, 0xFF);
            g = Math.min(g + 0x20, 0xFF);
            b = Math.min(b + 0x20, 0xFF);
        } else if (brightness > 200) {
            // Too bright → dim it a little using XOR
            r = r ^ 0x10;
            g = g ^ 0x10;
            b = b ^ 0x10;
        }

        // Recombine ARGB using bit shifting
        return ((a & 0xFF) << 24)
                | ((r & 0xFF) << 16)
                | ((g & 0xFF) << 8)
                | (b & 0xFF);
    }
}
