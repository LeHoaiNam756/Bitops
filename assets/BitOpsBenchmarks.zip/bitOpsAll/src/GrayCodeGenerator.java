/**
 * In digital logic, the Gray code is a binary numeral system where two successive values
 * differ in only one bit. It is used in error correction, digital encoders,
 * and genetic algorithms.
 *
 * <p>
 * The n-bit Gray code sequence can be generated using the formula:
 * <pre>
 *     Gray(i) = i ^ (i >> 1)
 * </pre>
 * where '^' is the XOR operator.
 *
 * <p> Example (3-bit Gray code):
 * <pre>
 *     i:   0 1 2 3 4 5 6 7
 *     Bin: 000 001 010 011 100 101 110 111
 *     Gray:000 001 011 010 110 111 101 100
 * </pre>
 *
 * @see <a href="https://en.wikipedia.org/wiki/Gray_code">Gray code - Wikipedia</a>
 */
public final class GrayCodeGenerator {
    private GrayCodeGenerator() {}

    /**
     * Generates an array of n-bit Gray codes as integers.
     *
     * @param n number of bits
     * @return array containing all 2ⁿ Gray codes
     */
    public static int[] generateGrayCodes(int n) {
        int size = 1 << n; // total 2^n codes
        int[] gray = new int[size];

        for (int i = 0; i < size; i++) {
            // Apply XOR between i and (i >> 1)
            gray[i] = i ^ (i >> 1);
        }

        return gray;
    }
}