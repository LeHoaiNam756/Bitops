public class halfPrecisionToFloat {
    public static int halfPrecisionToFloat(int hbits) {
        int sign = (hbits >>> 15) & 0x00000001;
        int exp = (hbits >>> 10) & 0x0000001F;
        int mantissa = hbits & 0x000003FF;

        int outExp = 0;
        int outMantissa = 0;

        if (exp == 0x1F) {
            outExp = 0xFF;
            if (mantissa != 0) {
                outMantissa = (mantissa << 13) | 0x400000;
            }
        } else if (exp == 0) {
            if (mantissa != 0) {
                outExp = 113;
                while ((mantissa & 0x400) == 0) {
                    mantissa = mantissa << 1;
                    outExp = outExp - 1;
                }
                outMantissa = (mantissa & 0x3FF) << 13;
            }
        } else {
            outExp = exp + 112;
            outMantissa = mantissa << 13;
        }

        return (sign << 31) | (outExp << 23) | outMantissa;
    }
}
