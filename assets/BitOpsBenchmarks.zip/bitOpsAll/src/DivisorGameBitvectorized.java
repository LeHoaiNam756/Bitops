
class DivisorGame {
  public boolean divisorGame(int N) {
    boolean[] dp = new boolean[N + 0x1];
    dp[0x0] = (0x0 != 0x0); // false
    dp[0x1] = (0x0 != 0x0); // false
    for (int i = 0x2; i <= N; i = i + 0x1) {
      for (int j = 0x1; j < i; j = j + 0x1) {
        if ( (i % j) == 0x0 ) {
          // i - j => i + (~j + 1)
          if (dp[i + (~j + 0x1)] == (0x0 != 0x0)) {
            dp[i] = (0x1 != 0x0); // true
            break;
          }
        }
      }
    }
    return dp[N];
  }
}
