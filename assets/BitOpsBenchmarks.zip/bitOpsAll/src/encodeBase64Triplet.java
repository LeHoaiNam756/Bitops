public class encodeBase64Triplet{
    public static int encodeBase64Triplet(int input) {
        int result = 0;

        for (int i = 0; i < 4; i++) {
            int shift = 18 - (i * 6);
            int index = (input >> shift) & 0x3F;

            int ascii;
            if (index < 26) {
                ascii = index + 65;
            } else if (index < 52) {
                ascii = index + 71;
            } else if (index < 62) {
                ascii = index - 4;
            } else if (index == 62) {
                ascii = 43;
            } else {
                ascii = 47;
            }

            result = (result << 8) | ascii;
        }

        return result;
    }
}
